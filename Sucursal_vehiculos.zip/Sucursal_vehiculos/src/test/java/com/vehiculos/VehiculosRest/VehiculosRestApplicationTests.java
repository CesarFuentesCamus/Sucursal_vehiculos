package com.vehiculos.VehiculosRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiculosRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
